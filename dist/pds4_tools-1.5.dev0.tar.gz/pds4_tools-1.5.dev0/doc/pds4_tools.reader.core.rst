pds4_tools.reader.core module
=============================

.. currentmodule:: pds4_tools.reader.core

Functions
---------

.. autosummary::

    pds4_read
    read_structures
    read_byte_data

Details
-------

.. function:: pds4_tools.read

    An alias of :func:`pds4_read`.

.. automodule:: pds4_tools.reader.core
    :members:
    :undoc-members:
    :show-inheritance:
